This free PHP template is courtesy of Redefined Web Design.

It is a basic template that uses PHP Includes to call the header and footer files.

If you run into any issues with this template, leave a comment in this thread:
http://www.redefinedwebdesign.com/free-php-website-template/