  <!--Begin Header-->
  <div id="header"></div>
    <div id="navigation"><!--Begin Navigation-->
      <ul>
        <li><a href="/">Home</a></li>
        <li><a href="/about.php">About</a></li>
        <li><a href="/contact.php">Contact</a></li>
      </ul>
    </div><!--End Navigation-->
  <!--End Header-->