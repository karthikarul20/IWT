<!--Begin Footer-->
  <div id="footer">Free Template Courtesy of a <a href="http://www.redefinedwebdesign.com/design-services/dallas-web-design/" target="_blank">Dallas Web Design</a> - Redefined Web Design
  </div><!--End Footer-->
    
  </div><!--End Container-->
</div><!--End Wrapper-->

</body>
</html>